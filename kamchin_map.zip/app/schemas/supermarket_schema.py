from pydantic import BaseModel
from datetime import datetime
from typing import Optional

class SupermarketBase(BaseModel):
    name: str
    status: str
    lat: float
    lng: float

class SupermarketCreate(SupermarketBase):
    pass

class SupermarketUpdate(BaseModel):
    name: Optional[str] = None
    status: Optional[str] = None
    lat: Optional[float] = None
    lng: Optional[float] = None

class SupermarketResponse(SupermarketBase):
    id: int
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True
