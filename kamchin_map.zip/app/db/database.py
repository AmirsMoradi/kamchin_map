from collections.abc import Generator
from sqlalchemy import create_engine
from sqlalchemy.orm import Session, sessionmaker
from sqlalchemy_utils import database_exists, create_database


connection_string = "mysql+pymysql://root:amir0221@localhost:3306/kachin_map"

if not database_exists(connection_string):
    create_database(connection_string)

engine = create_engine(
    connection_string,
    echo=False,
    pool_pre_ping=True,
    pool_recycle=1800,
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
    expire_on_commit=False,
)

def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


class DataAccess:
    """
    کلاس عمومی برای مدیریت عملیات پایه دیتابیس (CRUD)
    """
    def __init__(self, class_name, session: Session = None):
        self.class_name = class_name
        # دریافت سشن یا ساخت یک سشن جدید
        self.session = session or SessionLocal()

    def save(self, entity):
        self.session.add(entity)
        self.session.commit()
        self.session.refresh(entity)
        return entity

    def edit(self, entity):
        self.session.merge(entity)
        self.session.commit()
        return entity

    def remove(self, entity):
        self.session.delete(entity)
        self.session.commit()
        return entity

    def find_all(self):
        return self.session.query(self.class_name).all()

    def find_by_id(self, entity_id):
        return self.session.query(self.class_name).get(entity_id)

    def find_by(self, **kwargs):
        return self.session.query(self.class_name).filter_by(**kwargs).all()
