from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.db.database import DataAccess
from app.models.supermarket_model import Supermarket
from app.schemas.supermarket_schema import SupermarketCreate, SupermarketResponse
from app.services.supermarket_service import SupermarketService

router = APIRouter(prefix="/api/v1/markets", tags=["markets"])

def get_supermarket_service(db: Session = Depends(get_db)):
    data_access = DataAccess(Supermarket, db)
    return SupermarketService(data_access)

@router.get("", response_model=list[SupermarketResponse])
def get_markets(service: SupermarketService = Depends(get_supermarket_service)):
    return service.list_markets()

@router.post("", response_model=SupermarketResponse)
def create_market(data: SupermarketCreate, service: SupermarketService = Depends(get_supermarket_service)):
    return service.create_market(data)
