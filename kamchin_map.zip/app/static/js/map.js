const API_KEY = "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6ImM0ZTg2NmNhN2EyYjM4NjI3MjE3OTJiYjBkMjRkYmQyNmJhYWRiZWU0YThlNjAyMTM4YmM3NTU3MmI5ODYxMjczZjM2Y2NlNTliODM2NmMxIn0.eyJhdWQiOiI0MDc5NSIsImp0aSI6ImM0ZTg2NmNhN2EyYjM4NjI3MjE3OTJiYjBkMjRkYmQyNmJhYWRiZWU0YThlNjAyMTM4YmM3NTU3MmI5ODYxMjczZjM2Y2NlNTliODM2NmMxIiwiaWF0IjoxNzc4NjYyNDU3LCJuYmYiOjE3Nzg2NjI0NTcsImV4cCI6MTc4MTI1NDQ1Nywic3ViIjoiIiwic2NvcGVzIjpbImJhc2ljIl19.GSe4ZfVoVA7lqADd31wLMfpufsg5itc_aIYwTJaR410XVuRTXd_snbGUokKd6SuSIpZFTm3HWjnfzInIgxk5BeadCzrLyWl10InWxMBT-JXLHpZY60jydOMPV_Dwln1Pmi4JK0dnukgrCvOyZVJKV73Dt1viAnkadXOhOhZLPa25PAFfA9RtNYB9G1W1h3b-SnpLSeiGVjoEONrIEz5ABx0AgWs0DOUzsvaL-GLEQeNqJn5QjnJb0Q0JE1B0Q0r6_y5ReNvSDEoHy1KHkT4b0nXdvYVBGsfJwwVVSXIQYqZZTv25BaG6arszKMuvl6RUBSGwc9C-jS8ww-KIgXNkzg";

let map = L.map('map').setView([35.6892, 51.3890], 11);
let tempMarker = null;
let allMarkers = {};

L.tileLayer(`https://map.ir/shiveh/normal/z{z}/x{x}/y{y}.png?x-api-key=${API_KEY}`, {
    maxZoom: 18,
}).addTo(map);

function showNotification(message, type = 'success') {
    const area = document.getElementById('notification-area');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerText = message;
    area.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => area.removeChild(toast), 500);
    }, 3000);
}

const colorMap = {
    'green': 'green',
    'yellow': 'gold',
    'red': 'red'
};

map.on('click', function(e) {
    document.getElementById('marketLat').value = e.latlng.lat;
    document.getElementById('marketLng').value = e.latlng.lng;

    if (tempMarker) {
        map.removeLayer(tempMarker);
    }

    let status = document.getElementById('marketStatus').value || 'green';
    let color = colorMap[status];

    tempMarker = L.circleMarker(e.latlng, {
        radius: 8,
        fillColor: color,
        color: "#000",
        weight: 1,
        opacity: 1,
        fillOpacity: 0.8
    }).addTo(map);
});

async function loadMarkets() {
    for (let key in allMarkers) {
        map.removeLayer(allMarkers[key]);
    }
    allMarkers = {};

    try {
        const response = await fetch('/api/v1/markets');
        const markets = await response.json();

        markets.forEach(market => {
            let color = colorMap[market.status] || 'gray';
            let marker = L.circleMarker([market.lat, market.lng], {
                radius: 8,
                fillColor: color,
                color: "#000",
                weight: 1,
                opacity: 1,
                fillOpacity: 0.8
            }).addTo(map);

            marker.bindPopup(`<b>${market.name}</b><br>گرید: ${market.status}`);
            allMarkers[market.name] = marker;
        });
    } catch (error) {
        console.error('Error loading markets:', error);
    }
}

document.getElementById('marketForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const data = {
        name: document.getElementById('marketName').value,
        status: document.getElementById('marketStatus').value,
        color: document.getElementById('marketStatus').value,
        lat: parseFloat(document.getElementById('marketLat').value),
        lng: parseFloat(document.getElementById('marketLng').value)
    };

    try {
        const response = await fetch('/api/v1/markets', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            showNotification('ثبت با موفقیت انجام شد', 'success');
            if (tempMarker) map.removeLayer(tempMarker);
            document.getElementById('marketForm').reset();
            loadMarkets();
        } else {
            showNotification('خطا در ثبت سوپرمارکت', 'error');
        }
    } catch (error) {
        showNotification('خطای ارتباط با سرور', 'error');
    }
});

document.getElementById('deleteForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const name = document.getElementById('deleteMarketName').value;

    try {
        const response = await fetch(`/api/v1/markets/${encodeURIComponent(name)}`, {
            method: 'DELETE'
        });

        if (response.ok) {
            showNotification('حذف با موفقیت انجام شد', 'success');
            document.getElementById('deleteForm').reset();
            loadMarkets();
        } else {
            showNotification('در صورت خطا حذف انجام نشد (سوپرمارکت یافت نشد)', 'error');
        }
    } catch (error) {
        showNotification('خطای ارتباط با سرور', 'error');
    }
});

loadMarkets();
