from app.schemas.supermarket_schema import SupermarketCreate

class SupermarketService:
    def __init__(self, data_access):
        self.data_access = data_access

    def create_market(self, data: SupermarketCreate):
        return self.data_access.create(data.dict())

    def list_markets(self):
        return self.data_access.get_all()

    def get_market(self, market_id: int):
        return self.data_access.get_by_id(market_id)
